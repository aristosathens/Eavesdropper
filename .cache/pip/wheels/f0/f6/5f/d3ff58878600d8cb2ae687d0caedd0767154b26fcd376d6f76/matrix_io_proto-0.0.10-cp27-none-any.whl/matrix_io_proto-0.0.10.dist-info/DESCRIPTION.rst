========================
MATRIX Ecosystem protos
========================

matrix-protos contains the python classes generated from the 
protocol buffers available in the matrixprotos_ repository.

.. _`matrixprotos`: https://github.com/matrix-io/protocol-buffers


